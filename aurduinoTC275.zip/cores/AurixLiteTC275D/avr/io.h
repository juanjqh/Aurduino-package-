/* Dummy delay.h */

