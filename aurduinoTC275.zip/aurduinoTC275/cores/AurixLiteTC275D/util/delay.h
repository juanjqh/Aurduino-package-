/* Replace AVR delay with ShieldBuddy Delay */
#define _delay_us delayMicroseconds
