


void updateLed();
uint8_t timedOut();
void ResetTick();


extern int EnterBootLoader(void);
